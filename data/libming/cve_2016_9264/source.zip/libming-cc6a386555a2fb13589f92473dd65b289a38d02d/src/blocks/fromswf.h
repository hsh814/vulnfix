/*
    Ming, an SWF output library
    Copyright (C) 2001  Opaque Industries - http://www.opaque.net/

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* fromswf.h
 * 
 * $Id$
 *
 *
 * Notice: This header file contains declarations of functions and types that
 * are just used internally. All library functions and types that are supposed
 * to be publicly accessable are defined in ./src/ming.h.
 */

#ifndef SWF_FROMSWF_H_INCLUDED
#define SWF_FROMSWF_H_INCLUDED

#include "ming.h"
#include "block.h"
#include "character.h"
#include "output.h"

struct SWFPrebuiltClip_s
{
	struct SWFCharacter_s character;

	int frames;
	SWFOutput display;
};

struct SWFPrebuilt_s
{
	struct SWFBlock_s block;
	
	SWFOutput defines;
};
typedef struct SWFPrebuilt_s *SWFPrebuilt;

int SWFPrebuiltClipLength(SWFBlock block);

#endif /* SWF_FROMSWF_H_INCLUDED */

